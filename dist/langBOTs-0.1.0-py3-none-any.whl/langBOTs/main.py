# import scrapsplitvec
# import chain
# import query

# from scrapsplitvec import SSV
# from chain import MDL
# from query import Query


# retriever = SSV()
# qa_chain_instrucEmbed = MDL(retriever = retriever, device = 1)
# Query("hello")